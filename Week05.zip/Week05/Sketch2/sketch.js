let myCommands = ["Hey!", "Bye!", "Later!"]

function setup() {
createCanvas(600, 600);
background(255);
frameRate(1);

}

function draw() {
background(color(200));
for (var i = 0; i < myCommand.length; i++); {
  console.log(myCommand[i]);
}
text(myCommand[i], 300, 300);
i++;
}
